<?php
echo $content;
?>