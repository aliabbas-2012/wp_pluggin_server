<?php

//wp-load
require_once('../../../wp-load.php');

 
wp_rankie_update_rank_function_wrap();