<?php get_header(); ?>
  <div id="container" class="clearfix">  
   <div id="leftnav">
	  <?php get_sidebar(); ?>
    </div>
    <div id="rightnav">
	  <?php include (TEMPLATEPATH . '/sidebar2.php'); ?>
</div>
    <div id="content">

		<h3 class="center">Error 404 - Not Found</h3>

	</div>

<?php get_footer(); ?>
</div>
</body>
</html>