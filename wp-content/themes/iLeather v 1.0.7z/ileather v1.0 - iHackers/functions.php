<?php

if ( function_exists('register_sidebars') )
	register_sidebars(2);
?>