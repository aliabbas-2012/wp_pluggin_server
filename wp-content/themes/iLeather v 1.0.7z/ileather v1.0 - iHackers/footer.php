<div id="footer">
<p><strong>Copyright &copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?></strong> | <a href="feed:<?php bloginfo('rss2_url'); ?>">Entries </a> <a href="feed:<?php bloginfo('rss2_url'); ?>" title="Subscribe"><img src="<?php bloginfo('template_directory'); ?>/images/rss.png" alt="Subscribe" border="0" align="top" /></a> and <a href="feed:<?php bloginfo('comments_rss2_url'); ?>">Comments</a> <a href="feed:<?php bloginfo('rss2_url'); ?>" title="Subscribe"><img src="<?php bloginfo('template_directory'); ?>/images/rss.png" alt="Subscribe" border="0" align="top" /></a></p>
<a href="http://www.cheapbikesparts.com/cycles/">Bike Categories</a><img src="http://www.wpthemesarchive.com/i/spacer.gif">, iLeather by: <a href="http://bloggerlounge.net/">George C </a>| <a href="http://bloggerlounge.net/">Blogger Lounge</a>
<div id="icons"><a href="http://www.bloggerlounge.net/" title="Blogger Lounge"><img src="<?php bloginfo('template_directory'); ?>/images/bl.png" alt="Blogger Lounge" border="0" align="top" /></a>	</div>
</div>
<?php wp_footer(); ?>
