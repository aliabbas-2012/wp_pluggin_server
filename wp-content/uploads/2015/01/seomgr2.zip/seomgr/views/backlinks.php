<div style="display: block;">
<img src="<?php echo SEOMGR_BASE_URL.'assets/images/demo/'.$image.'.png'; ?>" />
</div>
